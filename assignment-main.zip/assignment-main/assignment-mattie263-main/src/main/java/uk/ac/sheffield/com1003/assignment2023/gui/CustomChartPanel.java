package uk.ac.sheffield.com1003.assignment2023.gui;

import uk.ac.sheffield.com1003.assignment2023.codeprovided.SongProperty;
import uk.ac.sheffield.com1003.assignment2023.codeprovided.gui.AbstractCustomChart;
import uk.ac.sheffield.com1003.assignment2023.codeprovided.gui.AbstractCustomChartPanel;
import uk.ac.sheffield.com1003.assignment2023.codeprovided.gui.AbstractSpotifyDashboardPanel;

import java.awt.*;
import java.awt.geom.Arc2D;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

/**
 * SKELETON IMPLEMENTATION
 */

public class CustomChartPanel extends AbstractCustomChartPanel {

    public CustomChartPanel(AbstractSpotifyDashboardPanel parentPanel, AbstractCustomChart customChart) {
        super(parentPanel, customChart);
    }

    private final List<String> circularBarLabel = Arrays.asList(SongProperty.POPULARITY.toString(),
            SongProperty.TEMPO.toString(), SongProperty.LOUDNESS.toString());
    private final List<String> radarLinesLabels = Arrays.asList(SongProperty.DANCEABILITY.toString(),
            SongProperty.ENERGY.toString(), SongProperty.SPEECHINESS.toString(), SongProperty.ACOUSTICNESS.toString()
            , SongProperty.INSTRUMENTALNESS.toString()
            , SongProperty.LIVENESS.toString(), SongProperty.VALENCE.toString());

    private final List<Color> radarChartLineColors = Arrays.asList(Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.ORANGE, Color.MAGENTA,
            Color.PINK);


    private double getValueForChart(SongProperty songProperty) {
        double averageValue = getCustomChart().getCustomChartAxesValues().get(songProperty).getAverage();
        double minValue = getCustomChart().getCustomChartAxesValues().get(songProperty).getMin();
        double maxValue = getCustomChart().getCustomChartAxesValues().get(songProperty).getMax();
        double computedValue = (averageValue - minValue) / (maxValue - minValue);
        /**
         * If values are not proper consider them as 1 full coverage else graph will not be drawn.
         */
        if(computedValue < 0 || Double.isNaN(computedValue) || Double.isInfinite(computedValue)) {
            return 1;
        }
        return computedValue;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        if(getCustomChart().getCustomChartAxesValues().size() == 0) {
            g2d.setColor(getBackground());
            g2d.fillRect(0, 0, getWidth(), getHeight());
            g2d.setColor(Color.BLACK);
            g2d.setStroke(new BasicStroke(5));
            g2d.drawString("No record found, hence not displaying chart", 100, 200);
            return;
        }
        int width = getWidth();
        int height = getHeight();
        List<Double> circularBarAttributes = new ArrayList<>();
        List<Double> radarBarAttributes = new ArrayList<>();

        circularBarAttributes.add(getValueForChart(SongProperty.POPULARITY));
        circularBarAttributes.add(getValueForChart(SongProperty.TEMPO));
        circularBarAttributes.add(getValueForChart(SongProperty.LOUDNESS));

        radarBarAttributes.add(getValueForChart(SongProperty.DANCEABILITY));
        radarBarAttributes.add(getValueForChart(SongProperty.ENERGY));
        radarBarAttributes.add(getValueForChart(SongProperty.SPEECHINESS));
        radarBarAttributes.add(getValueForChart(SongProperty.ACOUSTICNESS));
        radarBarAttributes.add(getValueForChart(SongProperty.INSTRUMENTALNESS));
        radarBarAttributes.add(getValueForChart(SongProperty.LIVENESS));
        radarBarAttributes.add(getValueForChart(SongProperty.VALENCE));

        int chartWidth = Math.min(width, height);
        int chartHeight = chartWidth / 2;
        int centerX = width / 2;
        int centerY = height / 2;

        drawCircularChart(g2d, centerX - chartWidth / 4, centerY, chartWidth / 2, chartHeight, circularBarAttributes);
        drawRadarChart(g2d, centerX - chartWidth / 4, centerY, chartWidth / 2, radarBarAttributes);
    }


    private void drawCircularChart(Graphics2D g2d, int x, int y, int width, int height, List<Double> attributes) {
        List<Color> circularChartColor = new ArrayList<>();
        double sum = 0;
        for (double attr : attributes) {
            sum += attr;
        }
        double incrementInAngle = 180.0 / sum;
        double startAngle = 90;
        for (double attr : attributes) {
            double sweepAngle = incrementInAngle * attr;
            Color color = Color.getHSBColor(new Random().nextInt(255), new Random().nextInt(100),
                    new Random().nextInt(150));
            g2d.setColor(color);
            circularChartColor.add(color);
            g2d.fill(new Arc2D.Double(x - width / 2, y - height / 2, width, height, startAngle, sweepAngle, Arc2D.PIE));
            startAngle += sweepAngle;

        }

        /**
         * Below code is to put the square boxed with property name and their respective color representation in circular bar
         * chart.
         */
        int boxSize = 20;
        int boxSpacing = 100;
        int boxY = (y - height / 2) + height + 20;
        int textY = boxY + boxSize + 15;
        for (int i = 0; i < attributes.size(); i++) {
            int boxX = (x - width / 2) + (i * boxSpacing);
            g2d.setColor(circularChartColor.get(i));
            g2d.fillRect(boxX, boxY, boxSize, boxSize);
            int textX = boxX + (boxSize / 2) - (8 * 3);
            g2d.setColor(Color.BLACK);
            g2d.drawString(circularBarLabel.get(i), textX, textY);
        }
    }

    private void drawRadarChart(Graphics2D g2d, int x, int y, int width, List<Double> attributes) {
        int numAttributes = attributes.size();
        double angleIncrement = Math.PI / (numAttributes - 1);
        int centerX = x;
        int centerY = y;

        int[] xPoints = new int[numAttributes];
        int[] yPoints = new int[numAttributes];

        for (int i = 0; i < numAttributes; i++) {
            double angle = angleIncrement * i - Math.PI / 2;
            double radius = attributes.get(i) * (width / 2);
            xPoints[i] = (int) (centerX + radius * Math.cos(angle));
            yPoints[i] = (int) (centerY + radius * Math.sin(angle));
            int labelX = (int) (centerX + (radius + 10) * Math.cos(angle));
            int labelY = (int) (centerY + (radius + 10) * Math.sin(angle));
            g2d.setColor(radarChartLineColors.get(i));
            g2d.setStroke(new BasicStroke(2));
            g2d.drawString(radarLinesLabels.get(i), labelX, labelY);
        }

        g2d.setStroke(new BasicStroke(3));
        for (int i = 0; i < numAttributes; i++) {
            g2d.setColor(radarChartLineColors.get(i));
            g2d.drawLine(centerX, centerY, xPoints[i], yPoints[i]);
        }
    }


}
