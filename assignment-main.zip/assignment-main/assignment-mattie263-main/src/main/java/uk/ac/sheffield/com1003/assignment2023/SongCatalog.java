package uk.ac.sheffield.com1003.assignment2023;

import uk.ac.sheffield.com1003.assignment2023.codeprovided.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 * SKELETON IMPLEMENTATION
 */
public class SongCatalog extends AbstractSongCatalog {
    public SongCatalog(String songFile)
            throws IllegalArgumentException, IOException {
        super(songFile);
    }

    @Override
    public SongPropertyMap parseSongEntryLine(String line) throws IllegalArgumentException {
        try {
            String[] songProperties = line.split("\t");
            if (songProperties.length != 14) {
                throw new IllegalArgumentException("Provided data is not correct, not matching with input data " +
                        "expected tabs:" + 14);
            }
            SongPropertyMap songPropertyMap = new SongPropertyMap();
            songPropertyMap.putDetail(SongDetail.NAME, songProperties[0]);
            songPropertyMap.putDetail(SongDetail.ARTIST, songProperties[1]);
            songPropertyMap.putProperty(SongProperty.DURATION, Double.valueOf(songProperties[2]));
            songPropertyMap.putDetail(SongDetail.ALBUM_NAME, songProperties[3]);
            songPropertyMap.putProperty(SongProperty.POPULARITY, Double.valueOf(songProperties[4]));
            songPropertyMap.putProperty(SongProperty.DANCEABILITY, Double.valueOf(songProperties[5]));
            songPropertyMap.putProperty(SongProperty.ENERGY, Double.valueOf(songProperties[6]));
            songPropertyMap.putProperty(SongProperty.LOUDNESS, Double.valueOf(songProperties[7]));
            songPropertyMap.putProperty(SongProperty.SPEECHINESS, Double.valueOf(songProperties[8]));
            songPropertyMap.putProperty(SongProperty.ACOUSTICNESS, Double.valueOf(songProperties[9]));
            songPropertyMap.putProperty(SongProperty.INSTRUMENTALNESS, Double.valueOf(songProperties[10]));
            songPropertyMap.putProperty(SongProperty.LIVENESS, Double.valueOf(songProperties[11]));
            songPropertyMap.putProperty(SongProperty.VALENCE, Double.valueOf(songProperties[12]));
            songPropertyMap.putProperty(SongProperty.TEMPO, Double.valueOf(songProperties[13]));
            return songPropertyMap;
        } catch (Exception ex) {
            throw new IllegalArgumentException("Failed to parse the song record, stopping the execution",
                    ex.getCause());
        }
    }

    @Override
    public List<SongEntry> getSongEntriesList(List<SongEntry> songEntryList, SongDetail songDetail, String name) {
        List<SongEntry> filteredSongEntryList =
                songEntryList.stream().filter(song->song.getSongDetail(songDetail).equals(name)).collect(Collectors.toList());
        return filteredSongEntryList;
    }

    @Override
    public double getMinimumValue(SongProperty songProperty, List<SongEntry> songEntriesList) throws NoSuchElementException {
        double minimumValue = Double.MAX_VALUE;
        for (SongEntry songEntry : songEntriesList) {
            if (songEntry.getSongProperty(songProperty) < minimumValue) {
                minimumValue = songEntry.getSongProperty(songProperty);
            }
        }
        return minimumValue;
    }

    @Override
    public double getMaximumValue(SongProperty songProperty, List<SongEntry> songEntriesList) throws NoSuchElementException {
        double maximumValue = Double.MIN_VALUE;
        for (SongEntry songEntry : songEntriesList) {
            if (songEntry.getSongProperty(songProperty) > maximumValue) {
                maximumValue = songEntry.getSongProperty(songProperty);
            }
        }
        return maximumValue;
    }

    @Override
    public double getAverageValue(SongProperty songProperty, List<SongEntry> songEntriesList) throws NoSuchElementException {
        double totalValue = 0.0;
        for (SongEntry songEntry : songEntriesList) {
            totalValue += songEntry.getSongProperty(songProperty);
        }
        int numberOfRecords = songEntriesList.size();
        return totalValue / numberOfRecords;
    }

    @Override
    public List<SongEntry> getFirstFiveSongEntries() {
        if (songEntriesList.size() <= 5) {
            return songEntriesList;
        }
        //If size is greater than 5 then only get first five elements.
        List<SongEntry> firstFiveEntryInList = new ArrayList<>();
        for (int i = 0; i <= 5; i++) {
            firstFiveEntryInList.add(songEntriesList.get(i));
        }
        return firstFiveEntryInList;
    }

}
