package uk.ac.sheffield.com1003.assignment2023;

import uk.ac.sheffield.com1003.assignment2023.codeprovided.*;
import uk.ac.sheffield.com1003.assignment2023.codeprovided.gui.AbstractSpotifyDashboardPanel;
import uk.ac.sheffield.com1003.assignment2023.codeprovided.gui.SpotifyDashboard;
import uk.ac.sheffield.com1003.assignment2023.gui.SpotifyDashboardPanel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * This is the main class used to run the assignment's GUI.
 *
 * @author Maria-Cruz Villa-Uriol (m.villa-uriol@sheffield.ac.uk)
 * @author Ayeshmantha Wijayagunethilake (a.wijayagunethilake@sheffield.ac.uk)
 * <p>
 * Copyright (c) University of Sheffield 2023
 */
public class SpotifyDashboardApp {
    private final AbstractSongCatalog songCatalog;
    private final List<Query> listOfQueries;

    /**
     * we will also accept as a definition of unique song entry, a song where there is
     * no other occurrence with the exact same combination of only song title and artist (not case sensitive)
     */
    private List<SongEntry> uniqueSongEntriesBasedOnSongNameAndArtistName;

    public SpotifyDashboardApp(String songFile, String queryFile) {
        AbstractSongCatalog songCatalog = null;
        List<Query> listOfQueries = null;
        try {
            songCatalog = new SongCatalog(songFile);
            List<String> queryTokens = new ArrayList<>(AbstractQueryParser.readQueryTokensFromFile(queryFile));
            try {
                listOfQueries = new ArrayList<>(new QueryParser().buildQueries(queryTokens));
            } catch (IllegalArgumentException e) {
                System.err.println(e);
            }
        } catch (IllegalArgumentException | IOException e) {
            System.err.println(e);
            System.exit(-1);
        }
        this.songCatalog = songCatalog;
        this.listOfQueries = listOfQueries;

    }

    public static void main(String[] args) {
        if (args.length == 0) {
            args = new String[]{
                    "./src/main/resources/spotify_songs.tsv",
                    "./src/main/resources/queries.txt"
            };
        }
        SpotifyDashboardApp spotifyDashboardApp = new SpotifyDashboardApp(args[0], args[1]);
        spotifyDashboardApp.startCLI();
        spotifyDashboardApp.startGUI();
    }

    public void startCLI() {
        // Basic song catalogue information
        printQuestionAnswers();

        // Queries
        printNumberQueries();
        executeQueries();
    }

    private void executeQueries() {
        System.out.println("Executing queries...");

        for (Query query : listOfQueries) {
            System.out.println(query.toString() + ":");
            List<SongEntry> queryResults = query.executeQuery(songCatalog);
            printSongEntries(queryResults);
            System.out.println();
        }
    }

    private void printNumberQueries() {
        System.out.println("The total number of queries are:" + listOfQueries.size());
    }

    private void printQuestionAnswers() {
        printNumberUniqueSongs();
        printNumberUniqueArtists();
        printAverageDurationAndAverageTempoOfSongsInUniqueList();
        printMaximumLoudnessAndMinimumTempo();
        printFirstFiveSongEntries();
    }

    private void printNumberUniqueArtists() {
        Set<String> uniqueArtists = new HashSet<>();
        for (SongEntry song : this.songCatalog.getSongEntriesList()) {
            //Ignore case sensitive
            String combination = song.getSongArtist().toLowerCase();
            uniqueArtists.add(combination);
        }
        System.out.println("The total number of unique artists in the dataset is: " + uniqueArtists.size());;

    }

    private void printNumberUniqueSongs() {
        System.out.println("The total number of unique songs in the dataset is: " + getUniqueSongEntriesBasedOnSongNameAndArtistName().size());
    }

    private void printFirstFiveSongEntries() {
        System.out.println("Printing first five song entries");
        printSongEntries(songCatalog.getFirstFiveSongEntries());
    }

    private void printMaximumLoudnessAndMinimumTempo() {
        double maximumLoudness = this.songCatalog.getMaximumValue(SongProperty.LOUDNESS,
                this.songCatalog.getSongEntriesList());
        double minimumTempo = this.songCatalog.getMinimumValue(SongProperty.TEMPO,
                this.songCatalog.getSongEntriesList());
        System.out.println("The maximum loudness of a song in the dataset is: " + String.format("%.3f",
                maximumLoudness));
        System.out.println("The minimum tempo of a song in the dataset is " + String.format("%.3f",
                minimumTempo));
    }

    private void printAverageDurationAndAverageTempoOfSongsInUniqueList() {
        List<SongEntry> uniqueSongsList = getUniqueSongEntriesBasedOnSongNameAndArtistName();
        double averageDuration = this.songCatalog.getAverageValue(SongProperty.DURATION, uniqueSongsList);
        double averageTempoDuration = this.songCatalog.getAverageValue(SongProperty.TEMPO, uniqueSongsList);
        System.out.println("The average duration of a song in the dataset is: " + String.format("%.3f", averageDuration));
        System.out.println("The average tempo of a song in the dataset is " + String.format("%.3f", averageTempoDuration));
    }

    /**
     * we will also accept as a definition of unique song entry, a song where there is
     * no other occurrence with the exact same combination of only song title and artist (not case sensitive)
     */
    private List<SongEntry> getUniqueSongEntriesBasedOnSongNameAndArtistName() {
        List<SongEntry> songsData = this.songCatalog.getSongEntriesList();
        List<SongEntry> uniqueSongs = songsData.stream()
                .collect(Collectors.toMap(
                        song -> song.getSongName().toLowerCase() + "|" + song.getSongArtist().toLowerCase(),
                        song -> song,
                        (existing, replacement) -> existing))
                .values()
                .stream()
                .collect(Collectors.toList());
        return uniqueSongs;
    }

    private void printSongEntries(List<SongEntry> songEntriesList) {
        if(songEntriesList.size() == 0) {
            System.out.println("No record found for this query.");
        }

        int count = 0;
        if(songEntriesList.size() > 20) {
            System.out.println("[Note:] Displaying only first 20 records out of " + songEntriesList.size());
        }
        for (SongEntry song : songEntriesList){
            System.out.println(song);
            if(count == 20) {
                break;
            }
            count++;
        }
    }

    public void startGUI() {
        // Start GUI
        AbstractSpotifyDashboardPanel spotifyDashboardPanel = new SpotifyDashboardPanel(songCatalog);
        SpotifyDashboard songDashboard = new SpotifyDashboard(spotifyDashboardPanel);
        songDashboard.setVisible(true);
    }
}
