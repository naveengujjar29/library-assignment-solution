package uk.ac.sheffield.com1003.assignment2023;

/**
 * SKELETON IMPLEMENTATION
 */

import uk.ac.sheffield.com1003.assignment2023.codeprovided.AbstractQueryParser;
import uk.ac.sheffield.com1003.assignment2023.codeprovided.Query;
import uk.ac.sheffield.com1003.assignment2023.codeprovided.SongProperty;
import uk.ac.sheffield.com1003.assignment2023.codeprovided.SubQuery;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

public class QueryParser extends AbstractQueryParser {

    public static final String SELECT = "select";
    public static final String WHERE = "where";
    public static final String AND = "and";

    @Override
    public List<Query> buildQueries(List<String> queryTokens) {
        List<SubQuery> subQueries = new ArrayList<>();
        List<SubQuery> currentQuerySubQueries = null;
        List<Query> queries = new ArrayList<>();
        boolean isConditionStarted = false;
        for (int i = 0; i < queryTokens.size(); i++) {
            if (queryTokens.get(i).equalsIgnoreCase(SELECT)) {
                if (currentQuerySubQueries != null) {
                    subQueries.addAll(new ArrayList<>(currentQuerySubQueries));
                    queries.add(new Query(new ArrayList<>(subQueries)));
                    subQueries.clear();
                }
                currentQuerySubQueries = new ArrayList<>();
                isConditionStarted = false;
            } else if (queryTokens.get(i).equalsIgnoreCase(WHERE)) {
                isConditionStarted = true;
            } else if (queryTokens.get(i).equalsIgnoreCase(AND)) {
            } else if (isConditionStarted && !queryTokens.get(i).equalsIgnoreCase(AND)) {
                SongProperty songProperty = SongProperty.fromName(queryTokens.get(i));
                String operation = queryTokens.get(i + 1);
                Double value = Double.valueOf(queryTokens.get(i + 2));
                SubQuery subQuery = new SubQuery(songProperty, operation, value);
                currentQuerySubQueries.add(subQuery);
                i += 2;
            }
        }
        //Handling last row computation
        subQueries.addAll(currentQuerySubQueries);
        queries.add(new Query(new ArrayList<>(subQueries)));
        return queries;
    }
}
