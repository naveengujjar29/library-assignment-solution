package uk.ac.sheffield.com1003.library;

/**
 * If you wish, write your own JUnit tests in this class.
 * See {@link TestLibrary} for reference.
 */
public class MyTests {

}
