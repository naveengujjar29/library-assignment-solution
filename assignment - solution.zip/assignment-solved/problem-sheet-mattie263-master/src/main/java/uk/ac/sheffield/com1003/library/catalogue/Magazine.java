package uk.ac.sheffield.com1003.library.catalogue;


/**
 * Magazine is another type of CatalogueItem.
 */
public class Magazine extends CatalogueItem {

    private int number;

    public Magazine(String title, int year, int number, int copies) {
        super(title, year, copies);
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    @Override
    public String toString() {
        return "Magazine: Title=" + getTitle() + "; Year=" + getYear() + "; Number=" + getNumber() + "; Copies=" + getCopies();
    }
}
