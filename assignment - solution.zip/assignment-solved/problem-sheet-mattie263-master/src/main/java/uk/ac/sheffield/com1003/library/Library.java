package uk.ac.sheffield.com1003.library;

import uk.ac.sheffield.com1003.library.catalogue.Book;
import uk.ac.sheffield.com1003.library.catalogue.CatalogueItem;
import uk.ac.sheffield.com1003.library.catalogue.Magazine;
import uk.ac.sheffield.com1003.library.exceptions.ItemAlreadyReturnedException;
import uk.ac.sheffield.com1003.library.exceptions.ItemNotFoundException;
import uk.ac.sheffield.com1003.library.exceptions.NoCopyAvailableException;

import java.time.LocalDateTime;
import java.util.*;

public class Library {
    /**
     * Use this constant to initialise the catalogue
     */
    private final int CATALOGUE_CAPACITY = 100;
    private String name;
    private CatalogueItem[] catalogue = new CatalogueItem[CATALOGUE_CAPACITY];
    private Loan[] loans = new Loan[CATALOGUE_CAPACITY];
    private int loanLength;

    public static final String ANSI_GREEN = "\u001B[32m";

    public static final String ANSI_BOLD = "\u001B[1m";
    public static final String ANSI_RESET = "\u001B[0m";

    /**
     * Constructor that initialises the library name to "Library"
     * and the loan length to 10 days
     */
    public Library() {
        this("Library", 10);
    }

    /**
     * Constructor that takes a library name as parameter and
     * initialises the loan length to 10 days
     *
     * @param name The name of the library
     */
    public Library(String name) {
        this(name, 10);
    }

    /**
     * Constructor that takes a library name and the loan length
     * as parameters
     *
     * @param name       The name of the library
     * @param loanLength The number of days books should be loaned for
     */
    public Library(String name, int loanLength) {
        this.name = name;
        this.loanLength = loanLength;
    }

    /**
     * Returns a simple welcome message
     *
     * @return "Welcome to <library name>"
     */
    public String welcome() {
        return "Welcome to " + getName();
    }

    /**
     * Returns the library name
     *
     * @return Library name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Add the given book to the catalogue.
     *
     * @param newItem Item to be added to catalogue
     * @return Returns true if there is space in the catalogue and new item is successfully added; false otherwise
     */
    public boolean addItem(CatalogueItem newItem) {
        for (int i = 0; i < catalogue.length; i++) {
            if (catalogue[i] == null) {
                catalogue[i] = newItem;
                return true;
            }
        }
        return false;
    }

    /**
     * If more than number of copies is removed then remove the catalogue item as well.
     *
     * @param catalogueItem
     * @throws ItemNotFoundException
     */
    private void removeCatalogueItem(CatalogueItem catalogueItem) throws ItemNotFoundException {
        for (int i = 0; i < catalogue.length; i++) {
            if (catalogue[i].equals(catalogueItem)) {
                System.out.println("Catalogue item " + catalogueItem + " has been removed successfully.");
                catalogue[i] = null;
            }
        }
    }

    /**
     * Finds item with given title or ISBN and removes a copy from the catalogue.
     * Assumes there are no duplicated title or ISBN.
     *
     * @param titleOrISBN Exact title or ISBN of the item to be removed.
     */
    public void removeItem(String titleOrISBN) throws ItemNotFoundException {
        CatalogueItem catalogueItem = findItem(titleOrISBN);
        catalogueItem.setCopies(catalogueItem.getCopies() - 1);
        if (catalogueItem.getCopies() < 0) {
            removeCatalogueItem(catalogueItem);
        }
    }

    /**
     * Find item with given title or ISBN and remove a given number of copies from the catalogue.
     * Assumes there are no duplicated title or ISBN.
     *
     * @param titleOrISBN Exact title or ISBN of the item to be removed
     * @param n           Number of copies to remove
     */
    public void removeItem(String titleOrISBN, int n) throws ItemNotFoundException {
        CatalogueItem catalogueItem = findItem(titleOrISBN);
        catalogueItem.setCopies(catalogueItem.getCopies() - n);
        if (catalogueItem.getCopies() < 0) {
            removeCatalogueItem(catalogueItem);
        }
    }

    /*
     * This overloaded method is written to handle the use case where particular edition of books are not available.
     * We can search for the prefix and catalogue and try to loan it if copies are available.
     */
    private boolean loanEditionItem(String titleOrISBN, Person author, Person user) throws ItemNotFoundException, NoCopyAvailableException {
        CatalogueItem catalogueItem = null;
        for (int i = 0; i < catalogue.length; i++) {
            if (catalogue[i] != null) {
                if (catalogue[i].getTitle().startsWith(titleOrISBN) && catalogue[i].isAvailable()) {
                    System.out.println("Prefix has been matched with the another edition version[" + catalogue[i].getTitle() + "], checking for author.");
                    if (((Book) catalogue[i]).getAuthor().equals(author)) {
                        System.out.println("Author is also same and copies are available, issuing this one.");
                        catalogueItem = catalogue[i];
                        break;
                    }
                }
            }
        }
        if (catalogueItem == null) {
            throw new ItemNotFoundException("Book with title or ISBN " + titleOrISBN + " not found.");
        }

        if (!catalogueItem.isAvailable()) {
            throw new NoCopyAvailableException("No copy of this title or ISBN" + titleOrISBN + "is available");
        }

        Loan loan = new Loan(catalogueItem, user, this.loanLength);
        catalogueItem.setCopies(catalogueItem.getCopies() - 1);
        for (int i = 0; i < loans.length; i++) {
            if (loans[i] == null) {
                loans[i] = loan;
                break;
            }
        }
        loan.printReceipt();
        return true;
    }

    /**
     * Registers the loan of a book given its exact title or ISBN.
     *
     * @param titleOrISBN The title or ISBN of the book to be loaned
     * @param user        Name of user loaning catalogue item
     * @return true if the item's title or ISBN exist in the catalogue and there is a copy available; false otherwise
     * @throws ItemNotFoundException    if a book with the given title does not exist in the catalogue
     * @throws NoCopyAvailableException if there are no copies available of the given book
     */
    public boolean loanItem(String titleOrISBN, Person user) throws ItemNotFoundException, NoCopyAvailableException {
        CatalogueItem catalogueItem = findItem(titleOrISBN);

        if (catalogueItem == null) {
            throw new ItemNotFoundException("Book with title or ISBN " + titleOrISBN + " not found.");
        }

        if (!catalogueItem.isAvailable()) {
            if (catalogueItem instanceof Book) {
                System.out.println("No Available copy with this title or edition, checking another edition for availability.");
                return loanEditionItem(titleOrISBN, ((Book) catalogueItem).getAuthor(), user);
            }
            throw new NoCopyAvailableException("No copy of this title " + titleOrISBN + "is available");
        }

        Loan loan = new Loan(catalogueItem, user, this.loanLength);
        catalogueItem.setCopies(catalogueItem.getCopies() - 1);
        for (int i = 0; i < loans.length; i++) {
            if (loans[i] == null) {
                loans[i] = loan;
                break;
            }
        }
        return true;
    }

    /**
     * Find an item in the catalogue given a title or ISBN.
     *
     * @param titleOrISBN Title or ISBN of item to find
     * @return The catalogue item found or null otherwise
     */
    private CatalogueItem findItem(String titleOrISBN) throws ItemNotFoundException {
        for (int i = 0; i < catalogue.length; i++) {
            if (catalogue[i] != null) {
                if (catalogue[i].getTitle().equals(titleOrISBN) || ((Book) catalogue[i]).getIsbn().equals(titleOrISBN)) {
                    return catalogue[i];
                }
            }
        }
        throw new ItemNotFoundException("Item does not exist with title or ISBN " + titleOrISBN);
    }

    private Loan findLoan(String titleOrIsbn, Person person) {
        for (Loan loan : loans) {
            if (loan.getItem() != null) {
                if (loan.getItem() instanceof Book) {
                    if (loan.getItem().getTitle().equals(titleOrIsbn) || ((Book) loan.getItem()).getIsbn().equals(titleOrIsbn)) {
                        if (loan.getUser().equals(person)) {
                            return loan;
                        }
                    }
                } else if (loan.getItem() instanceof Magazine) {
                    if (loan.getItem().getTitle().equals(titleOrIsbn)) {
                        if (loan.getUser().equals(person)) {
                            return loan;
                        }
                    }
                }
            }
        }
        return null;
    }

    /*
     * Return the item based on Title and Person.
     */
    public void returnItem(String titleOrIsbn, Person person) throws ItemAlreadyReturnedException {
        Loan loan = findLoan(titleOrIsbn, person);
        this.returnItem(loan);
    }

    /**
     * Mark the item in a Returns a given loan
     */
    public void returnItem(Loan loan) throws ItemAlreadyReturnedException {
        if (loan.getReturnedDate() != null) {
            throw new ItemAlreadyReturnedException("Item has been already return on " + loan.getReturnedDate());
        }
        System.out.println(ANSI_BOLD + ANSI_GREEN + loan + " has been returned.\n" + ANSI_RESET);
        loan.getItem().addCopy();
        loan.returnItem();
    }

    /*
     * Overload method to find the loans based on Person and title or ISBN
     * then it will call the extend loan only.
     */
    public void extendLoan(String titleOrIsbn, Person person, int days) throws ItemAlreadyReturnedException {
        Loan loan = findLoan(titleOrIsbn, person);
        this.extendLoan(loan, days);
    }

    /**
     * Extends the given loan
     */
    public void extendLoan(Loan loan, int days) throws ItemAlreadyReturnedException {
        if (loan.getReturnedDate() != null) {
            throw new ItemAlreadyReturnedException("Item has been already return on " + loan.getReturnedDate());
        }
        loan.extendLoan(days);
    }

    /**
     * Return the number of copies available for a given catalogue item
     *
     * @param item the item
     * @return number of copies available for the given item
     */
    public int copiesAvailable(CatalogueItem item) {
        return item.getCopies();
    }

    /**
     * Returns the current list of books in the catalogue excluding nulls
     *
     * @return Array of books contained in the catalogue (excluding nulls)
     */
    public CatalogueItem[] getCatalogue() {
        ArrayList<CatalogueItem> catalogueItems = new ArrayList<>();
        for (int i = 0; i < catalogue.length; i++) {
            if (catalogue[i] != null) {
                catalogueItems.add(catalogue[i]);
            }
        }
        return catalogueItems.toArray(new CatalogueItem[catalogueItems.size()]);
    }

    /**
     * Print the full catalogue in the following format (sorted by title)
     * ====================
     * <Output of call to {@link Library#welcome()}>
     * Catalogue
     * ====================
     * <Output of call to method toString in the item>
     * ====================
     */
    public void printCatalogue() {

        List<CatalogueItem> catalogueData = Arrays.asList(getCatalogue());

        /*
         * Sort the data based on title as per requirement
         */
        Collections.sort(catalogueData, new Comparator<CatalogueItem>() {
            @Override
            public int compare(CatalogueItem o1, CatalogueItem o2) {
                return o1.getTitle().compareTo(o2.getTitle());
            }
        });

        System.out.println("====================");
        System.out.println(welcome());
        System.out.println("Catalogue");
        System.out.println("====================");
        for (CatalogueItem catalogueItem : catalogueData) {
            System.out.println(catalogueItem);
        }
        System.out.println("====================");
        System.out.println();
    }

    ;

    /**
     * Print the list of loans that are overdue (i.e., due date has passed),
     * sorted by the number of days they are overdue by, and in the following
     * format:
     * ====================
     * Loans Overdue
     * ====================
     * <Output of call to {@link Loan#toString()}; one overdue loan>
     * ====================
     */
    public void printOverdue() {
        System.out.println("Overdue Loans:");
        for (Loan loan : loans) {
            if (loan == null) {
                break;
            }
            if (loan.getReturnedDate() == null && loan.getDueDate().isAfter(LocalDateTime.now())) {
                System.out.println(loan);
            }
        }
    }

}
