package uk.ac.sheffield.com1003.library;

import uk.ac.sheffield.com1003.library.catalogue.Book;
import uk.ac.sheffield.com1003.library.catalogue.Magazine;
import uk.ac.sheffield.com1003.library.exceptions.ItemAlreadyReturnedException;
import uk.ac.sheffield.com1003.library.exceptions.ItemNotFoundException;
import uk.ac.sheffield.com1003.library.exceptions.NoCopyAvailableException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;

/*
 * Main class to test the library functionality.
 */
public class App {

    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_RESET = "\u001B[0m";

    /*
    * User Name constants that are being used to get the book on loan below.
     */
    private static Person LOAN_PERSON_1 = new Person("Dummy1", "User");
    private static Person LOAN_PERSON_2 = new Person("Dummy2", "User");
    private static Person LOAN_PERSON_3 = new Person("Dummy3", "User");
    private static Person LOAN_PERSON_4 = new Person("Dummy4", "User");
    private static Person LOAN_PERSON_5 = new Person("Dummy5", "User");
    private static Person LOAN_PERSON_6 = new Person("Dummy6", "User");




    /**
     * This method will test the book loan functionality
     *
     * @param library
     */
    public static void testBookLoan(Library library) {

    }


    public static void main(String[] args) throws IOException, ParseException, NoCopyAvailableException, ItemNotFoundException, ItemAlreadyReturnedException {


        Library library = new Library("Sheffield Central Library", 10);

        // Add the first book
        Person authorRobertMartin = new Person("Robert Martin");
        Book bookCleanCode = new Book("Clean Code", authorRobertMartin, "9780136083238", 2008);

        Person charlesDarwinAuthor = new Person("Charles Darwin");
        Book speciesOriginBook = new Book("On the Origin of Species", charlesDarwinAuthor, "123456", 2021);

        Person charlesDarwinAuthor1 = new Person("Darwin,Charles");
        Book speciesOriginBookEdition2 = new Book("On the Origin of Species (2nd Edition)", charlesDarwinAuthor1, "56789", 2023);

        speciesOriginBook.setCopies(1);
        speciesOriginBookEdition2.setCopies(2);

        // Read the content from resources directory

        InputStream inputStream = App.class.getResourceAsStream("/Lee60.bib");
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

        StringBuilder contentBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            contentBuilder.append(line).append("\n");
        }
        reader.close();
        String fileContent = contentBuilder.toString();

        //Add the second book after reading from file data
        Book book2 = Book.fromBibtex(fileContent);

        /**
         * Both the books has been added
         */
        library.addItem(bookCleanCode);
        library.addItem(book2);
        library.addItem(speciesOriginBook);
        library.addItem(speciesOriginBookEdition2);

        // Print the available catalogue available
        library.printCatalogue();

        // Provide the Clean Code book and another one on loan.
        library.loanItem("Clean Code", LOAN_PERSON_1);
        library.loanItem("To Kill a Mockingbird", LOAN_PERSON_2);
        library.loanItem("On the Origin of Species", LOAN_PERSON_4);

        // Print what is overdue loan items
        library.printOverdue();

        System.out.println("====================\n");


        // Clean code book has been returned
        library.returnItem("Clean Code", LOAN_PERSON_1);
        library.extendLoan("To Kill a Mockingbird", LOAN_PERSON_2, 20);

        // Now lets see  what is overdue loan items
        library.printOverdue();

        System.out.println("\n");

        // Created a magazine
        Magazine magazine = new Magazine("Sports Magazine", 2024, 200, 160);

        // Added the Magazine to library.
        library.addItem(magazine);

        // Loan the magazine to another user
        library.loanItem("Sports Magazine", LOAN_PERSON_3);

        System.out.print("As this magazine has been loaned hence available copies should be subtracted by 1.");
        System.out.println("Available copies of magazine, Sports Magazine is:::::" + magazine.getCopies());
        System.out.println("\n");

        // Lets' see what is overdue loan now.
        library.printOverdue();
        System.out.println("\n");

        // Returned the Magazine
        library.returnItem("Sports Magazine", LOAN_PERSON_3);

        library.printOverdue();

        System.out.println("\n");
        // Availble copies in library of Magazine
        System.out.println("Magazine has been returned hence copy should be back to original 160. Available copies of magazine  Sports Magazine is:::::" + magazine.getCopies());

        // All the copies of Magazine has been removed from library.
        library.removeItem("Sports Magazine", 160);
        System.out.println("160 copies has been removed of the Magazine, available copy:::::" + magazine.getCopies());

        // Now Try to loan this magazine
        try {
            library.loanItem("Sports Magazine", LOAN_PERSON_5);
        } catch (NoCopyAvailableException ex) {
            System.out.println(ANSI_RED + "No copies is available of this Magazine, hence can not be loaned." + ANSI_RESET);
        }

        System.out.println("\n\n");
        // Print the library catalogue
        library.printCatalogue();


        try {
            library.loanItem("On the Origin of Species", LOAN_PERSON_6);
        } catch (NoCopyAvailableException ex) {
            System.out.println(ANSI_RED + "No copies is available of this Book, hence can not be loaned" + ANSI_RESET);
        }

        //Overdue loan, based on output, we can see that user is able to get the loan on  2nd edition book.
        library.printOverdue();



    }

}
