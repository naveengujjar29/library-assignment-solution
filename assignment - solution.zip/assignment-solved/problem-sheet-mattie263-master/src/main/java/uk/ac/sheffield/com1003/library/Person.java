package uk.ac.sheffield.com1003.library;

import java.text.ParseException;
import java.util.Objects;

public class Person {
    String firstName;
    String lastName;

    /*
     * Parse the Author name based on space or comma and assigned properly.
     */
    public Person(String fullName) throws ParseException {
        if (fullName.contains(",")) {
            String[] parsedName = fullName.split(",");
            this.lastName = parsedName[0];
            this.firstName = parsedName[1];
        } else if (fullName.contains(" ")) {
            String[] parsedName = fullName.split(" ");
            this.lastName = parsedName[1];
            this.firstName = parsedName[0];
        } else {
            throw new ParseException("Full name contains other character than comma and space, not a valid name", 5);
        }
    }

    public Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * Returns a string representation of a person
     *
     * @return A string representation of a person in
     * the format "<last name>, <first name>"
     */
    @Override
    public String toString() {
        return this.lastName + ", " + this.firstName;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return Objects.equals(firstName, person.firstName) && Objects.equals(lastName, person.lastName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName);
    }
}
