package uk.ac.sheffield.com1003.library.catalogue;

import uk.ac.sheffield.com1003.library.Person;

import javax.swing.*;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.SubmissionPublisher;

public class Book extends CatalogueItem  {

    public enum Genre {UNSPECIFIED, NONFICTION} ;
    private Person author;
    private String isbn;

    private Genre genre;

    public Book(String title) {
        super(title);
    }

    public Book(String title, Person author) {
        super(title);
        this.author = author;
    }

    public Book(String title, Person author, String isbn) {
        super(title);
        this.author = author;
        this.isbn = isbn;
    }

    public Book(String title, Person author, String isbn, int year) {
        super(title, year);
        this.author = author;
        this.isbn = isbn;
    }

    public Book(String title, Person author, String isbn, int year, Genre genre) {
        super(title, year);
        this.author = author;
        this.genre = genre;
    }

    public Book(String title, Person author, String isbn, int year, Genre genre, int nCopies) throws IllegalArgumentException {
        super(title, year, nCopies);
        this.author = author;
        this.genre = genre;
        this.isbn = isbn;
    }

    public Person getAuthor() {
        return author;
    }

    public void setAuthor(Person person) {
        this.author = person;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (other == null || getClass() != other.getClass()) return false;
        Book book = (Book) other;
        return Objects.equals(author, book.author) && Objects.equals(isbn, book.isbn) && genre == book.genre;
    }

    private static String extractValue(String line) {
        int startIndex = line.indexOf("{");
        int endIndex = line.lastIndexOf("}");
        if (startIndex != -1 && endIndex != -1) {
            return line.substring(startIndex + 1, endIndex).trim();
        }
        return null;
    }

    public static Book fromBibtex(String bibtex) {
        String[] splittedLines = bibtex.split("\n");
        String title = null, author = null, isbn = null, year = null;
        for(String line: splittedLines) {
            if (line.contains("title")) {
                title = extractValue(line);
            } else if (line.contains("author")) {
                author = extractValue(line);
            } else if (line.contains("isbn")) {
                isbn = extractValue(line);
            } else if (line.contains("year")) {
                year = extractValue(line);
            }
        }
        Person p = null;
        try {
            p = new Person(author);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return new Book(title, p, isbn, Integer.valueOf(year));
    }

    /**
     * Returns a string representation of a book
     *
     * @return A string representation of a book in
     * the format "Book: Author=<{@link Person#toString()}>; ISBN=<ISBN>; Genre=<Book genre>"
     */
    @Override
    public String toString() {
        if(this.genre != null) {
            return "Book: Author="+this.author+ "; ISBN=" + this.isbn +"; Genre="+this.genre;
        } else {
            return "Book: Author="+this.author+ "; ISBN=" + this.isbn +";";
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(author, isbn, genre);
    }


}
