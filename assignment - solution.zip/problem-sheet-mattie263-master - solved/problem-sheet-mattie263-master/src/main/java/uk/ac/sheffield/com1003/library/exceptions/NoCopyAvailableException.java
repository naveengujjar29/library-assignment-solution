package uk.ac.sheffield.com1003.library.exceptions;

public class NoCopyAvailableException extends Exception {
    public NoCopyAvailableException() {
    }

    public NoCopyAvailableException(String message) {
        super(message);
    }
}
