package uk.ac.sheffield.com1003.library.exceptions;

public class ItemAlreadyReturnedException extends Exception {
    public ItemAlreadyReturnedException() {
    }

    public ItemAlreadyReturnedException(String message) {
        super(message);
    }
}
