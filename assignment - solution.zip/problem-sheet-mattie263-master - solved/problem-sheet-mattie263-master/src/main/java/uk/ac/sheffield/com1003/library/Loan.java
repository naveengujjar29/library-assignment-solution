package uk.ac.sheffield.com1003.library;

import uk.ac.sheffield.com1003.library.catalogue.Book;
import uk.ac.sheffield.com1003.library.catalogue.CatalogueItem;
import uk.ac.sheffield.com1003.library.catalogue.Magazine;
import uk.ac.sheffield.com1003.library.exceptions.ItemAlreadyReturnedException;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Loan {

    private CatalogueItem item;
    private Person user;
    private LocalDateTime loanDate;
    private LocalDateTime dueDate;
    private LocalDateTime returnedDate;

    /**
     * Constructor that takes as parameters the item being loaned,
     * the user borrowing the item, and the loan length.
     * Sets the loan date and time to
     * the current date using {@link LocalDateTime#now()},
     * the due date to the current date plus loan length
     * and the returned date to null.
     *
     * @param item       CatalogueItem being loaned
     * @param user       Person loaning item
     * @param loanLength Number of days the loan is valid for
     */
    public Loan(CatalogueItem item, Person user, int loanLength) {
        this.item = item;
        this.user = user;
        this.loanDate = LocalDateTime.now();
        this.dueDate = this.loanDate.plusDays(loanLength);
        this.returnedDate = null;
    }

    public CatalogueItem getItem() {
        return this.item;
    }

    public Person getUser() {
        return this.user;
    }

    public LocalDateTime getLoanDate() {
        return this.loanDate;
    }

    public LocalDateTime getReturnedDate() {
        return this.returnedDate;
    }

    public LocalDateTime getDueDate() {
        return this.dueDate;
    }

    /**
     * Prints loan receipt in the following format:
     * <Loan date in format dd-MM-yyyy HH-mm-ss>
     * <User name> has borrowed <Book title>
     * Date due: <Date item is due to be returned>
     * Returned: <Returned date and time in format dd-MM-yyyy HH-mm-ss if already returned; otherwise "n/a">
     * Thank you!
     */
    public void printReceipt() {
        // Formating the date.
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH-mm-ss");
        System.out.println(this.loanDate.format(formatter));
        System.out.println(this.user + " has borrowed " + this.item.getTitle());
        System.out.println("Date due: " + this.dueDate.format(formatter));
        if (this.returnedDate != null) {
            System.out.println("Returned: " + this.returnedDate.format(formatter));
        } else {
            System.out.println("Returned: n/a");
        }
    }

    /**
     * Updates field {@link Loan#returnedDate} with current date and time
     *
     * @throws ItemAlreadyReturnedException if the item was already returned
     */
    public void returnItem() {
        this.returnedDate = LocalDateTime.now();
    }

    /**
     * Extends the loan term by adding the given amount of days to field {@link Loan#dueDate}
     *
     * @throws ItemAlreadyReturnedException if the item was already returned
     */
    public void extendLoan(int days) {
        this.dueDate = this.dueDate.plusDays(days);
    }

    /**
     * Returns a string representation of a Loan
     *
     * @return A string representation of a loan in
     * the format "Loan: User=<User name>; Item=<Book title>; Type=<"Book" or "Magazine">; Due=<Due date dd-MM-yyyy>"
     */
    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String type = "";
        if (this.item instanceof Book) {
            type = "Book";
        } else if (this.item instanceof Magazine) {
            type = "Magazine";
        }
        return "Loan: User=" + this.user + "; Item=" + this.item.getTitle() + "; Type=" + type + "; Due=" + this.dueDate.format(formatter);
    }
}